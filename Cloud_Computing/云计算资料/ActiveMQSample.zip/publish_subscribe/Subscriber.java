package publish_subscribe;

import javax.jms.JMSException;

public class Subscriber {
	public static void main(String[] args) throws JMSException {

		ConnFactory cf = new ConnFactory();

		Consumer1 consumer1 = new Consumer1(cf.createConnection(), "Topic1", "Consumer1");
		Consumer1 consumer2 = new Consumer1(cf.createConnection(), "Topic1", "Consumer2");
		Consumer2 consumer3 = new Consumer2(cf.createConnection(), "Topic2", "Consumer3");

		consumer1.start();
		consumer2.start();
		consumer3.start();

		consumer1.receive();
		consumer2.receive();
	}
}
